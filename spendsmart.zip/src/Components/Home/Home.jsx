
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Doughnut } from 'react-chartjs-2';
import './Home.css';
import {
  Chart as ChartJS,
  ArcElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { useNavigate } from 'react-router-dom';

ChartJS.register(ArcElement, Title, Tooltip, Legend);

const Home = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [income, setIncome] = useState(0);
  const [expenses, setExpenses] = useState([]);
  const [monthlyBudget, setMonthlyBudget] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const currentDate = new Date();
  const monthName = currentDate.toLocaleString('ro-RO', { month: 'long' });
  const capitalizedMonthName = monthName.charAt(0).toUpperCase() + monthName.slice(1);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem('auth_token');
        if (!token) {
          navigate('/');
          return;
        }
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

        const profileRes = await axios.get('/profile');
        if (profileRes.data?.user) {
          setUser(profileRes.data.user);
        }

        const finRes = await axios.get('/api/get-financial-data');
        const { income, expenses, monthly_budget } = finRes.data;

        setIncome(income || 0);
        setExpenses(expenses || []);
        setMonthlyBudget(monthly_budget || 0);
        setError(null);
      } catch (err) {
        console.error('Error fetching data:', err);
        if (err.response?.status === 401) {
          localStorage.removeItem('auth_token');
          delete axios.defaults.headers.common['Authorization'];
          navigate('/');
          return;
        }
        setError('Eroare la încărcarea datelor.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [navigate]);

  const totalExpenses = expenses.reduce((acc, exp) => acc + (parseFloat(exp.amount) || 0), 0);
  const remainingBudget = monthlyBudget - totalExpenses;

  const chartData = {
    labels: ['Cheltuieli', 'Rămas din buget'],
    datasets: [
      {
        data: [totalExpenses, remainingBudget],
        backgroundColor: ['#e74c3c', '#2ecc71'],
        borderColor: ['#c0392b', '#27ae60'],
        borderWidth: 1
      }
    ]
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom'
      }
    }
  };

  if (loading) return <p style={{ textAlign: 'center' }}>Se încarcă datele...</p>;
  if (error) return <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>;

  return (
    <div className="home-root-container">
      <div className="home-header">
        <h2>Bine ai revenit în aplicația ta financiară</h2>
      </div>

      <div className="home-summary-boxes">
        <div className="home-summary-card green">
          <h3>Venituri</h3>
          <p>{income.toFixed(2)} RON</p>
        </div>
        <div className="home-summary-card red">
          <h3>Cheltuieli</h3>
          <p>{totalExpenses.toFixed(2)} RON</p>
        </div>
        <div className="home-summary-card blue">
          <h3>Buget lunar</h3>
          <p>{monthlyBudget.toFixed(2)} RON</p>
        </div>
      </div>

      <div className="home-legend">
        <div><span className="legend-income"></span> Venituri</div>
        <div><span className="legend-expense"></span> Cheltuieli</div>
        <div><span className="legend-budget"></span> Buget</div>
      </div>

      <div className="home-sections">
        <div className="section">
          <h3>Cheltuieli Recente</h3>
          {expenses.length > 0 ? (
            expenses.slice(0, 5).map((exp, idx) => (
              <div key={idx} className="home-expense-item">
                <span className="home-expense-category">{exp.name}</span>
                <span className="home-expense-amount">{parseFloat(exp.amount).toFixed(2)} RON</span>
                <span className="home-expense-date">{new Date(exp.date).toLocaleDateString('ro-RO')}</span>
              </div>
            ))
          ) : (
            <p>Nu există cheltuieli recente.</p>
          )}
        </div>

        <div className="section">
          <h3>Progres Buget</h3>
          <div className="home-progress-bar">
            <div
              className="home-progress-fill"
              style={{
                width: `${Math.min((totalExpenses / monthlyBudget) * 100, 100)}%`,
                backgroundColor: totalExpenses > monthlyBudget ? '#e74c3c' : '#2ecc71'
              }}
            />
          </div>
          <p style={{ marginTop: '10px' }}>
            Ai cheltuit {totalExpenses.toFixed(2)} RON din {monthlyBudget.toFixed(2)} RON
          </p>
        </div>

        <div className="section" style={{ height: '300px' }}>
          <h3>Comparație Buget vs Cheltuieli</h3>
          <Doughnut data={chartData} options={chartOptions} />
        </div>
      </div>
    </div>
  );
};

export default Home;
