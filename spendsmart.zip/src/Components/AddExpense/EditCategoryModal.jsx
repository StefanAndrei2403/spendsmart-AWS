import React, { useState, useEffect } from 'react';
import './EditExpenseModal.css';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FaTimes } from 'react-icons/fa';


const EditExpenseModal = ({ expense, categories, onClose, onSave }) => {
  const [editedExpense, setEditedExpense] = useState({ ...expense });

  useEffect(() => {
    setEditedExpense({ ...expense });
  }, [expense]);

  const handleChange = (field, value) => {
    setEditedExpense((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(editedExpense);
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <h3>Editează Cheltuiala</h3>
          <button className="close-btn" onClick={onClose}>
            <FaTimes />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="modal-form">
          <label>Nume cheltuială</label>
          <input
            type="text"
            value={editedExpense.name}
            onChange={(e) => handleChange('name', e.target.value)}
          />

          <label>Sumă</label>
          <input
            type="number"
            value={editedExpense.amount}
            onChange={(e) => handleChange('amount', e.target.value)}
          />

          <label>Data</label>
          <DatePicker
            selected={new Date(editedExpense.date)}
            onChange={(date) => handleChange('date', date)}
            dateFormat="dd.MM.yyyy"
            className="datepicker"
          />

          <label>Categorie</label>
          <select
            value={editedExpense.category_id}
            onChange={(e) => handleChange('category_id', parseInt(e.target.value))}
          >
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.name}
              </option>
            ))}
          </select>

          <div className="checkbox-wrapper">
            <input
              type="checkbox"
              checked={editedExpense.planned_impulsive}
              onChange={(e) => handleChange('planned_impulsive', e.target.checked)}
              id="impulsiv-checkbox"
            />
            <label htmlFor="impulsiv-checkbox">Cheltuială neplanificată / impulsivă</label>
          </div>

          <button type="submit" className="primary-btn">
            Salvează modificările
          </button>
        </form>
      </div>
    </div>
  );
};

export default EditExpenseModal;
